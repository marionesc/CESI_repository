##### Exercice n�2  : traitement du signal et filtrage num�rique #######

% Q1. Compl�ter l'ent�te ci-dessous pour d�clarer la fonction filt_num

function .................

% chargement des donnees signal
load data_signal;

% Obtention de la longueur du signal 
N = .................

% Obtention de la fr�quence d'�chantillonnage Fe � partir de la variable t 
% Rappel : Fe = 1/Te. Te �tant l'intervalle entre 2 �chantillons de temps

Fe = ................


% Filtrage

% Si pas de param�tres en entr�e de la fonction filt_num 
% param�tres par d�faut
%  
if (..........)
  
  % les valeurs par d�faut
  SNR = 15; % rapport signal � bruit
  ordre = 5; % ordre du filtre num�rique
  A = 1; % amplitude 
  display = 1;

else 

 SNR = ................
 ordre = ..............
 A = ............
 display = ...............
 
endif

sigma = sqrt((A^2/2)*10^(-SNR/10));
bruit = sigma*rand(1,N);
signal_bruit = A*signal + bruit;


% Filtre

A = 1;
B = (1./ordre).*ones(1,ordre); 
   
[H,f] = freqz(B,A,Fe);


% f donner entre [0,pi] => normalisation de f entre [0,Fs/2]

f = f*Fe/(2*pi); 
   
signal_output= filter(B,A,signal_bruit);
N_output = length(signal_output);
t_output = 0 :(1/Fe): (N_output-1)*(1/Fe);

if display ==1
  
 #### Affichage des resultats actif ####

 %--- Sur premier cadran (utiliser subplot) : 
 %    Module du filtre H en decibels en fonction de la fr�quence 
 .......................
 .......................
 .......................
 .......................
 
 
 %--- Sur deuxi�me cadran (utiliser subplot) : 
 %     superposition du signal avant filtrage et apr�s filtrage
 %     label en x : temps
 %     titre : signaux avant et apr�s filtrage
 ..................
 .................
 .................
 .................
 
 
elseif display ==0

 varargout{1} = ................
 varargout{2} = ................
 varargout{3} = ................
 varargout{4} = ................
 varargout{5} = ................
 varargout{6} = ................

endif





