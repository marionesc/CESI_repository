clear all;
close all;

% Dans ce 3�me exercice, on se propose de concevoir l'arbre de Huffman
% et de mettre en �vidence la pertinence de l'algorithme pour la compression de donn�es

load data 

# Chargement de la data 
% h 1
% j 1 
% n 1
% l 2
% i 3
% m 4
% a 8

% L a premi�re colonne donne les caract�res
% la seconde colonne donne le nombre d'apparition du caract�re concern�
% EXEMPLE :
% stats(1,1) donne h
% stats(1,2) donne 1 :  h apparait effectivement une seule fois dans la phrase etudiee
% ATTENTION  : ICI le nombre d'apparition est de type chaine
%            : pour toute operation arithmetique, il faut convertir eh nombre              
%            : avec str2num() 
                   
                
% Q1. Calculer la taille en bits du fichier (c'est  � dire de la phrase en fait)
%     avec la formule SC = nombre de bits x nombre de lettres total dans la phrase
%     nombre de caracteres doit �tre d�duits � partir de la variable stats (suite au chargement de la data)
%     en utilisant sum() et str2num()

nbits = 3; 
nb_lettres_total = ...................

SC =  ..............;

printf("La taille du fichier est %d bits\n",SC);



% Chargement de l'arbre 

load data_Arbre;
% Arbre = 
% h1g
% j1d
% n2g
% l3g
% i4g
% m5g
% a6g

% La premi�re colonne donne les caract�res
% la seconde colonne donne le niveau dans l'arbre (en partant du bas de l'arbre) du caract�re concern�
% La troisi�me colonne indique si la branche est � gauche ou � droite
% EXEMPLE :
% Arbre(1,1) indique le caract�re 'h'
% Arbre(1,2) indique qu'on se situe au 1er niveau dans l'arbre
% Arbre(1,3) indique que la branche est � gauche


% ATTENTION  : ICI le niveau est de type type chaine
%            : pour toute operation arithmetique, il faut convertir eh nombre              
%            : avec str2num() 


% initiation de l'indice caract�re 
% idx_car = 1 indique qu'on traite d'abord le caract�re 'h'
% idx_car = 2 indique qu'on traitera le caractere 'j'
% ect ...
% jusqu"� idx_car = 7 qui indique le caractere 'a'
idx_car = 1;
niveau_arbre_total = 6; % nombre de niveaux total de l'arbre
nbcar_total = 7; % nombre de caracteres 'h' 'j' 'n' 'l' 'i' 'm' 'a'


% Q2. Compl�ter la boucle while () en int�grant les lignes permettant d'affecter les codes pour les caracteres
%     se situant sur les niveaux 2,3,4 et 5

while (idx_car <= nbcar_total)  % on balaye les lignes de l'Arbre, c'est a dire les caract�res de 'h' � 'a' 
    
    % si le niveau est de 1
    if (str2num(Arbre(idx_car,2)) == 1)
   
         % si la branche est � gauche, on attribue le code '111110'
         if (strcmp(Arbre(idx_car,3),'g'))
           code{idx_car} = '111110';
           
           % apres affectation du code, on passe au caractere suivant pour connaitre son code 
           idx_car = idx_car+1;
         elseif (strcmp(Arbre(idx_car,3),'d'))
           
           % si la branche est � droite, on attribue le code '111111'
           code{idx_car} = '111111';
           % apres affectation du code, on passe au caractere suivant pour connaitre son code 
           idx_car = idx_car+1;
       endif
       
       
    endif
    
   %  Int�gration des lignes permettant d'affecter les codes pour les caracteres
   %  se situant sur les niveaux 2,3,4 et 5
   % .......
   % .......
   % .......
   % .......
   % .......
    
    
    % si le niveau est de 6
    if (str2num(Arbre(idx_car,2)) == 6)
   
         if (strcmp(Arbre(idx_car,3),'g'))
           code{idx_car} = '0';
           idx_car = idx_car+1;
         elseif (strcmp(Arbre(idx_car,3),'d'))
           
           code{i} = '1';
           idx_car = idx_car+1;
      
         endif
       
    endif
    
     
end


% Q3. Calculer la taille du fichier apres compression 
% length(code{i}) donne la taille en bits du code du caract�re n�i
% on r�cup�re le nombre d'apparition du caract�re n�i � partir de stats (utiliser str2num() pour une conversion en num�rique)
AC = 0;
for i = 1 : nbcar_total 

  AC = ....................... 

endfor


printf("La taille du fichier est %d bits\n",AC);

% Q4.Completer la ligne ci-dessous pour avoir le taux de compression  
printf("Le taux de compression est de %d %% \n",...............);







