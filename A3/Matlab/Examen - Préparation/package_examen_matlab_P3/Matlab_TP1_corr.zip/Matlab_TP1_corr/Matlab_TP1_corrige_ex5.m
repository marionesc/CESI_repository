clear ;
clc;

display("Programme de calcul de surface") ;

L = input("Entrez la longueur : \n");
l = input("Entrez la largeur : \n");

S = L.*l;

printf("La valeur de surface est %d\n",S);

