tic
N = 10^5;
u = zeros(1,N);
un= 1;
u(1) = 1;
for n=2:N
  %u(n) = 3;
  un = 3;
endfor
toc
