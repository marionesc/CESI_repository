clear all;
close all;

res = Horner();