% Rappeler notion de variables locales
% res, a, b : variables locales
function res = Produit (a,b)
  res = a*b;
endfunction

