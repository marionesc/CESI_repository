%   Creer des variables en sortie 
##clear all;
##disp(['Saisie de 2 valeurs']);
##[Fe, fo ] = Saisir();

clear all;

% SCENARIO 1
%[Fe]  = Saisir2();



% SCENARIO 2
%[Fe,fo]  = Saisir2();



% SCENARIO 3
[Fe,fo,N]  = Saisir2();


% SCENARIO 4
%[Fe,fo,N]  = Saisir2();








